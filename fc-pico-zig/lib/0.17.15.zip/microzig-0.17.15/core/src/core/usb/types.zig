const std = @import("std");
const EndianInt = @import("../mem.zig").EndianInt;

pub const ClassSubclassProtocol = extern struct {
    /// Class of device, giving a broad functional area.
    pub const ClassCode = enum(u8) {
        Unspecified = 0x00,
        Audio = 0x01,
        CDC = 0x02,
        HID = 0x03,
        Physical = 0x05,
        Image = 0x06,
        Printer = 0x07,
        MassStorage = 0x08,
        Hub = 0x09,
        CDC_Data = 0x0A,
        SmartCard = 0x0B,
        ContentSecurity = 0x0D,
        Video = 0x0E,
        PersonalHealthcare = 0x0F,
        AudioVideoDevice = 0x10,
        BillboardDevice = 0x11,
        Type_C_Bridge = 0x12,
        BulkDisplayProtocol = 0x13,
        MCTP_Over_USB_ProtocolEndpoint = 0x14,
        I3C = 0x3C,
        DiagnosticDevice = 0xDC,
        WirelessController = 0xE0,
        Miscellaneous = 0xEF,
        ApplicationSpecific = 0xFE,
        VendorSpecific = 0xFF,
        _,

        pub fn Subclass(self: @This()) type {
            return @field(ClassSubclassProtocol.Subclass, @tagName(self));
        }

        pub fn Protocol(self: @This()) type {
            return @field(ClassSubclassProtocol.Protocol, @tagName(self));
        }
    };

    pub const Subclass = struct {
        pub const Default = enum(u8) {
            Unspecified = 0x00,
            VendorSpecific = 0xFF,
            _,
        };

        pub const Unspecified = Default;
        pub const Audio = Default;

        pub const CDC = enum(u8) {
            Unspecified = 0x00,
            VendorSpecific = 0xFF,
            /// Direct Line Control Model
            DirectLine = 0x01,
            /// Abstract Control Model
            Abstract = 0x02,
            /// Telephone Control Model
            Telephone = 0x03,
            /// Multi-Channel Control Model
            MultChannel = 0x04,
            /// CAPI Control Model
            CAPI = 0x05,
            /// Ethernet Networking Control Model
            Ethernet = 0x06,
            /// ATM Networking Control Model
            ATM_Networking = 0x07,
            /// Wireless Handset Control Model
            WirelessHeadest = 0x08,
            /// Device Management
            DeviceManagement = 0x09,
            /// Mobile Direct Line Model
            MobileDirect = 0x0A,
            /// OBEX
            OBEX = 0x0B,
            /// Ethernet Emulation Model
            EthernetEmulation = 0x0C,
            /// Network Control Model
            Network = 0x0D,
            _,
        };

        pub const HID = enum(u8) {
            Unspecified = 0x00,
            VendorSpecific = 0xFF,
            ///
            Boot = 0x01,
            _,
        };

        pub const Physical = Default;
        pub const Image = Default;
        pub const Printer = Default;

        pub const MassStorage = enum(u8) {
            /// SCSI command set not reported. De facto use.
            Unspecified = 0x00,
            /// Allocated by USB-IF for RBC. RBC is defined outside of USB.
            RBC = 0x01,
            /// Allocated by USB-IF for MMC-5 (ATAPI). MMC-5 is defined outside of USB.
            MMC_5 = 0x02,
            /// Obsolete. Was QIC-157
            QIC_157 = 0x03,
            /// Specifies how to interface Floppy Disk Drives to USB
            UFI = 0x04,
            /// Obsolete. Was SFF-8070i
            SFF_8070i = 0x05,
            /// SCSI transparent command set. Allocated by USB-IF for SCSI. SCSI standards are defined outside of USB.
            SCSI = 0x06,
            /// LSDFS. specifies how host has to negotiate access before trying SCSI
            LSD_FS = 0x07,
            /// Allocated by USB-IF for IEEE 1667. IEEE 1667 is defined outside of USB.
            IEEE_1667 = 0x08,
            /// Specific to device vendor. De facto use
            VendorSpecific = 0xFF,
            _,
        };

        pub const Hub = Default;

        pub const CDC_Data = enum(u8) {
            Unused = 0,
            VendorSpecific = 0xFF,
            _,
        };

        pub const SmartCard = Default;
        pub const ContentSecurity = Default;
        pub const Video = Default;
        pub const PersonalHealthcare = Default;
        pub const AudioVideoDevice = Default;
        pub const BillboardDevice = Default;
        pub const Type_C_Bridge = Default;
        pub const BulkDisplayProtocol = Default;
        pub const MCTP_Over_USB_ProtocolEndpoint = Default;
        pub const I3C = Default;
        pub const DiagnosticDevice = Default;
        pub const WirelessController = Default;
        pub const Miscellaneous = Default;
        pub const ApplicationSpecific = Default;
        pub const VendorSpecific = Default;
    };

    pub const Protocol = struct {
        pub const Default = enum(u8) {
            NoneRequired = 0x00,
            VendorSpecific = 0xFF,
            _,
        };

        pub const Unspecified = Default;
        pub const Audio = Default;

        pub const CDC = enum(u8) {
            /// USB specification No class specific protocol required
            NoneRequired = 0x00,
            /// ITU-T V.250 AT Commands: V.250 etc
            AT_ITU_T_V_250 = 0x01,
            /// PCCA-101 AT Commands defined by PCCA-101
            AT_PCCA_101 = 0x02,
            /// PCCA-101 AT Commands defined by PCCA-101 & Annex O
            AT_PCCA_101_O = 0x03,
            /// GSM 7.07 AT Commands defined by GSM 07.07
            AT_GSM_7_07 = 0x04,
            /// 3GPP 27.07 AT Commands defined by 3GPP 27.007
            AT_3GPP_27_07 = 0x05,
            /// C-S0017-0 AT Commands defined by TIA for CDMA
            AT_C_S0017_0 = 0x06,
            /// USB EEM Ethernet Emulation module
            USB_EEM = 0x07,
            /// External Protocol: Commands defined by Command Set Functional Descriptor
            External = 0xFE,
            /// USB Specification Vendor-specific
            VendorSpecific = 0xFF,
            _,
        };

        pub const HID = enum(u8) {
            NoneRequired = 0x00,
            VendorSpecific = 0xFF,
            ///
            Boot = 0x01,
            _,
        };

        pub const Physical = Default;
        pub const Image = Default;
        pub const Printer = Default;

        pub const MassStorage = enum(u8) {
            /// USB Mass Storage Class Control/Bulk/Interrupt (CBI) Transport with command completion interrupt
            CBI_with_interrupt = 0x00,
            /// USB Mass Storage Class Control/Bulk/Interrupt (CBI) Transport with no command completion interrupt
            CBI_no_interrupt = 0x01,
            /// USB Mass Storage Class Bulk-Only (BBB) Transport
            BulkOnly = 0x50,
            /// Allocated by USB-IF for UAS. UAS is defined outside of USB.
            UAS = 0x62,
            /// Specific to device vendor De facto use
            VendorSpecific = 0xFF,
            _,
        };

        pub const Hub = Default;

        pub const CDC_Data = enum(u8) {
            NoneRequired = 0,
            VendorSpecific = 0xFF,
            /// Network Transfer Block
            NetworkTransferBlock = 0x01,
            /// Physical interface protocol for ISDN BRI
            ISDN_BRI = 0x30,
            /// HDLC
            HDLC = 0x31,
            /// Transparent
            Transparent = 0x32,
            /// Management protocol for Q.921 data link protocol
            Management_Q_921 = 0x50,
            /// Data link protocol for Q.931
            DataLink_Q_931 = 0x51,
            /// TEI-multiplexor for Q.921 data link protocol
            TEI_Multiplexor_Q_921 = 0x52,
            /// Data compression procedures
            DataCompressionProcedures = 0x90,
            /// Euro-ISDN protocol control
            Euro_ISDN = 0x91,
            /// V.24 rate adaptation to ISDN
            RateAdaptation_V_24 = 0x92,
            /// CAPI Commands
            CAPI = 0x93,
            /// Host based driver. Note: This protocol code should only be used
            /// in messages between host and device to identify the host driver
            /// portion of a protocol stack.
            HostBasedDriver = 0xFD,
            /// CDC Specification The protocol(s) are described using a Protocol
            /// Unit Functional Descriptors on Communications Class Interface
            SpecifiedIn_PUF_Descriptor = 0xFE,
            _,
        };

        pub const SmartCard = Default;
        pub const ContentSecurity = Default;
        pub const Video = Default;
        pub const PersonalHealthcare = Default;
        pub const AudioVideoDevice = Default;
        pub const BillboardDevice = Default;
        pub const Type_C_Bridge = Default;
        pub const BulkDisplayProtocol = Default;
        pub const MCTP_Over_USB_ProtocolEndpoint = Default;
        pub const I3C = Default;
        pub const DiagnosticDevice = Default;
        pub const WirelessController = Default;
        pub const Miscellaneous = Default;
        pub const ApplicationSpecific = Default;
        pub const VendorSpecific = Default;
    };

    /// Class code, distinguishing the type of interface.
    class: ClassCode,
    /// Interface subclass code, refining the class of interface.
    subclass: u8,
    /// Protocol within the interface class/subclass.
    protocol: u8,

    pub const unspecified: @This() =
        .from(.Unspecified, .Unspecified, .NoneRequired);

    pub const vendor_specific: @This() =
        .from(.VendorSpecific, .VendorSpecific, .VendorSpecific);

    pub fn from(
        comptime class: ClassCode,
        subclass: class.Subclass(),
        protocol: class.Protocol(),
    ) @This() {
        return .{
            .class = class,
            .subclass = @backingInt(subclass),
            .protocol = @backingInt(protocol),
        };
    }
};

/// Types of transfer that can be indicated by the `attributes` field on `EndpointDescriptor`.
pub const TransferType = enum(u2) {
    Control = 0,
    Isochronous = 1,
    Bulk = 2,
    Interrupt = 3,
};

/// The types of USB SETUP requests that we understand.
pub const SetupRequest = enum(u8) {
    get_status = 0x00,
    clear_feature = 0x01,
    set_feature = 0x03,
    set_address = 0x05,
    get_descriptor = 0x06,
    set_descriptor = 0x07,
    get_configuration = 0x08,
    set_configuration = 0x09,
    _,
};

pub const DeviceStatus = extern struct {
    const Flags = packed struct(u8) {
        self_powered: bool,
        remote_wakeup: bool,
        reserved: u6 = 0,
    };

    flags: Flags,
    reserved: u8 = 0,

    pub fn create(self_powered: bool, remote_wakeup: bool) @This() {
        return .{ .flags = .{ .self_powered = self_powered, .remote_wakeup = remote_wakeup } };
    }
};

pub const FeatureSelector = enum(u8) {
    EndpointHalt = 0x00,
    DeviceRemoteWakeup = 0x01,
    TestMode = 0x02,
    // The remaining features only apply to OTG devices.
    _,
};

/// USB deals in two different transfer directions, called OUT (host-to-device)
/// and IN (device-to-host). In the vast majority of cases, OUT is represented
/// by a 0 byte, and IN by an `0x80` byte.
pub const Dir = enum(u1) {
    out = 0,
    in = 1,
};

pub const Endpoint = packed struct(u8) {
    // There are up to 15 endpoints for each direction.
    pub const Num = enum(u4) {
        ep0 = 0,
        ep1,
        ep2,
        ep3,
        ep4,
        ep5,
        ep6,
        ep7,
        ep8,
        ep9,
        ep10,
        ep11,
        ep12,
        ep13,
        ep14,
        ep15,
    };

    num: Num,
    _padding: u3 = 0,
    dir: Dir,

    pub inline fn out(num: Num) @This() {
        return .{ .num = num, .dir = .out };
    }

    pub inline fn in(num: Num) @This() {
        return .{ .num = num, .dir = .in };
    }
};

pub const RequestType = packed struct(u8) {
    recipient: Recipient,
    type: Type,
    direction: Dir,

    pub const Type = enum(u2) {
        standard,
        class,
        vendor,
        other,
    };

    pub const Recipient = enum(u5) {
        device,
        interface,
        endpoint,
        other,
        _, // Reserved
    };

    // The standard requests
    pub const set_address: RequestType = .{};
};

/// Layout of an 8-byte USB SETUP packet.
pub const SetupPacket = packed struct(u64) {
    /// Request metadata: recipient, type, direction.
    request_type: RequestType,
    /// Request. Standard setup requests are in the `SetupRequest` enum.
    /// Devices can extend this with additional types as long as they don't
    /// conflict.
    request: u8,
    /// A simple argument of up to 16 bits, specific to the request.
    value: EndianInt(u16, .little),
    index: EndianInt(u16, .little),
    /// If data will be transferred after this request (in the direction given
    /// by `request_type`), this gives the number of bytes (OUT) or maximum
    /// number of bytes (IN).
    length: EndianInt(u16, .little),

    pub fn format(self: SetupPacket, writer: *std.Io.Writer) !void {
        try writer.print("request_type={} request={} value={} index={} length={}", .{
            self.request_type,
            self.request,
            self.value.native(),
            self.index.native(),
            self.length.native(),
        });
    }

    pub fn to_standard_request(pkt: *const SetupPacket) *const StandardRequest {
        return @ptrCast(pkt);
    }

    /// A grouping of the first two fields so we can switch on them.
    pub const StandardRequest = packed struct(u16) {
        recipient: RequestType.Recipient,
        type: RequestType.Type = .standard,
        direction: Dir,
        request: SetupRequest,

        // zig fmt: off
        pub const clear_feature_device:    StandardRequest = .{ .direction = .out, .recipient = .device,    .request = .clear_feature     };
        pub const clear_feature_interface: StandardRequest = .{ .direction = .out, .recipient = .interface, .request = .clear_feature     };
        pub const clear_feature_endpoint:  StandardRequest = .{ .direction = .out, .recipient = .endpoint,  .request = .clear_feature     };
        pub const set_address:             StandardRequest = .{ .direction = .out, .recipient = .device,    .request = .set_address       };
        pub const set_configuration:       StandardRequest = .{ .direction = .out, .recipient = .device,    .request = .set_configuration };
        pub const set_descriptor:          StandardRequest = .{ .direction = .out, .recipient = .device,    .request = .set_descriptor    };
        pub const set_feature_device:      StandardRequest = .{ .direction = .out, .recipient = .device,    .request = .set_feature       };
        pub const set_feature_interface:   StandardRequest = .{ .direction = .out, .recipient = .interface, .request = .set_feature       };
        pub const set_feature_endpoint:    StandardRequest = .{ .direction = .out, .recipient = .endpoint,  .request = .set_feature       };
        pub const set_interface:           StandardRequest = .{ .direction = .out, .recipient = .interface, .request = .set_interface     };
        pub const get_configuration:       StandardRequest = .{ .direction = .in,  .recipient = .device,    .request = .get_configuration };
        pub const get_descriptor:          StandardRequest = .{ .direction = .in,  .recipient = .device,    .request = .get_descriptor    };
        pub const get_interface:           StandardRequest = .{ .direction = .in,  .recipient = .interface, .request = .get_interface     };
        pub const get_status_device:       StandardRequest = .{ .direction = .in,  .recipient = .device,    .request = .get_status        };
        pub const get_status_interface:    StandardRequest = .{ .direction = .in,  .recipient = .interface, .request = .get_status        };
        pub const get_status_endpoint:     StandardRequest = .{ .direction = .in,  .recipient = .endpoint,  .request = .get_status        };
        pub const synch_frame:             StandardRequest = .{ .direction = .in,  .recipient = .endpoint,  .request = .synch_frame       };
        // zig fmt: on
    };
};

/// Represents USB or device version, in binary coded decimal.
pub const Version = extern struct {
    pub const DigitPair = packed struct(u8) {
        low: u4,
        high: u4,

        pub fn from(value: u7) @This() {
            return .{ .low = @intCast(value % 10), .high = @intCast(value / 10) };
        }
    };

    minor: DigitPair,
    major: DigitPair,

    pub const v1_00: @This() = .from(1, 0);
    pub const v1_10: @This() = .from(1, 10);
    pub const v1_11: @This() = .from(1, 11);
    pub const v2_00: @This() = .from(2, 0);
    pub const v2_10: @This() = .from(2, 10);

    pub fn from(major: u7, minor: u7) @This() {
        return .{
            .minor = .from(minor),
            .major = .from(major),
        };
    }
};

/// Represents packet length.
pub const Len = u11;
