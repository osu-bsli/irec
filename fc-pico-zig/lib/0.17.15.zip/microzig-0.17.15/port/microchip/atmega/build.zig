const std = @import("std");
const microzig = @import("microzig/build-internals");

const Self = @This();

chips: struct {
    atmega328p: *const microzig.Target,
    atmega32u4: *const microzig.Target,
},

boards: struct {
    arduino: struct {
        nano: *const microzig.Target,
        uno_rev3: *const microzig.Target,
    },
    adafruit: struct {
        itsybitsy_32u4: *const microzig.Target,
    },
    emakefun: struct {
        rf_nano_v3: *const microzig.Target,
    },
},

pub fn init(dep: *std.Build.Dependency) ?Self {
    const b = dep.builder;

    const atpack = b.lazyDependency("atpack", .{}) orelse return null;
    const avr5_target: std.Target.Query = .{
        .cpu_arch = .avr,
        .cpu_model = .{ .explicit = &std.Target.avr.cpu.avr5 },
        .os_tag = .freestanding,
        .abi = .eabi,
    };

    const chip_atmega328p: microzig.Target = .{
        .dep = dep,
        .preferred_binary_format = .hex,
        .zig_target = avr5_target,
        .chip = .{
            .name = "ATmega328P",
            .url = "https://www.microchip.com/en-us/product/atmega328p",
            .register_definition = .{
                .atdf = atpack.path("atdf/ATmega328P.atdf"),
            },
            .memory_regions = &.{
                .{ .tag = .flash, .offset = 0x000000, .length = 32 * 1024, .access = .rx },
                .{ .tag = .ram, .offset = 0x800100, .length = 2048, .access = .rw },
            },
        },
        .hal = .{
            .root_source_file = b.path("src/hals/ATmega328P.zig"),
        },
        .linker_script = .{
            .generate = .{ .memory_regions_and_sections = .{ .rodata_location = .ram } },
        },
        .bundle_compiler_rt = false,
    };

    const chip_atmega32u4: microzig.Target = .{
        .dep = dep,
        .preferred_binary_format = .hex,
        .zig_target = avr5_target,
        .chip = .{
            .name = "ATmega32U4",
            .url = "https://www.microchip.com/en-us/product/ATmega32U4",
            .register_definition = .{
                .atdf = atpack.path("atdf/ATmega32U4.atdf"),
            },
            .memory_regions = &.{
                .{ .tag = .flash, .offset = 0x000000, .length = 32 * 1024, .access = .rx },
                .{ .tag = .ram, .offset = 0x800100, .length = 2560, .access = .rw },
            },
        },
        .linker_script = .{
            .generate = .{ .memory_regions_and_sections = .{ .rodata_location = .ram } },
        },
        .bundle_compiler_rt = false,
    };

    return .{
        .chips = .{
            .atmega328p = chip_atmega328p.derive(.{}),
            .atmega32u4 = chip_atmega32u4.derive(.{}),
        },
        .boards = .{
            .arduino = .{
                .nano = chip_atmega328p.derive(.{
                    .board = .{
                        .name = "Arduino Nano",
                        .url = "https://docs.arduino.cc/hardware/nano",
                        .root_source_file = b.path("src/boards/arduino_nano.zig"),
                    },
                }),
                .uno_rev3 = chip_atmega328p.derive(.{
                    .board = .{
                        .name = "Arduino Uno Rev3",
                        .url = "https://docs.arduino.cc/hardware/uno-rev3",
                        .root_source_file = b.path("src/boards/arduino_uno.zig"),
                    },
                }),
            },
            .adafruit = .{
                .itsybitsy_32u4 = chip_atmega32u4.derive(.{
                    .board = .{
                        .name = "Adafruit ItsyBitsy 32u4",
                        .url = "https://www.adafruit.com/product/3677",
                        .root_source_file = b.path("src/boards/itsybitsy_32u4.zig"),
                    },
                }),
            },
            .emakefun = .{
                .rf_nano_v3 = chip_atmega328p.derive(.{
                    .board = .{
                        .name = "Emakefun RF-Nano V3.0",
                        .url = "https://github.com/emakefun/rf-nano",
                        .root_source_file = b.path("src/boards/rf_nano_v3.zig"),
                    },
                }),
            },
        },
    };
}

pub fn build(b: *std.Build) void {
    _ = b.step("test", "Run platform agnostic unit tests");
}
