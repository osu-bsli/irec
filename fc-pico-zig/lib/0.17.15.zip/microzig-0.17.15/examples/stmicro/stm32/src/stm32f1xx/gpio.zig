const microzig = @import("microzig");

const stm32 = microzig.hal;
const rcc = stm32.rcc;
const gpio = stm32.gpio;
const time = stm32.time;

pub const panic = microzig.panic;

pub const std_options = microzig.std_options(.{});

comptime {
    _ = microzig.export_startup();
}

pub fn main() !void {
    _ = try rcc.apply(.{
        .SYSCLKSource = .PLL1_P,
        .PLLSourceVirtual = .HSE_Div_PREDIV,
        .PLLMUL = .Mul9,
        .APB1CLKDivider = .Div2,
        .RTCClockSelection = .LSI,
        .flags = .{
            .RTCUsed_ForRCC = true,
            .HSEOscillator = true,
        },
    });
    rcc.enable_clock(.GPIOC);

    // You can choose the time counting method between RTC or a general purpose Timer (TIM2-TIM5)!
    time.init_rtc();
    //time.init_timer(.TIM2);

    const led = gpio.Pin.from_port(.C, 13);

    led.set_output_mode(.general_purpose_push_pull, .max_50MHz);
    while (true) {
        time.sleep_ms(100);
        led.toggle();
    }
}
