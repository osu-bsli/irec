const std = @import("std");
const microzig = @import("microzig");
const gpio = microzig.hal.gpio;

comptime {
    _ = microzig.export_startup();
}

// ATtiny84: use PA0 as the LED pin
const led_pin = gpio.pin(.a, 0);

pub fn main() void {
    led_pin.set_direction(.output);

    while (true) {
        busy_sleep(20_000);
        led_pin.toggle();
    }
}

pub fn busy_sleep(comptime limit: comptime_int) void {
    if (limit <= 0) @compileError("limit must be non-negative!");

    comptime var bits = 0;
    inline while ((1 << bits) <= limit) {
        bits += 1;
    }

    const I = @Int(.unsigned, bits);

    var i: I = 0;
    while (i < limit) : (i += 1) {
        std.mem.doNotOptimizeAway(i);
    }
}
