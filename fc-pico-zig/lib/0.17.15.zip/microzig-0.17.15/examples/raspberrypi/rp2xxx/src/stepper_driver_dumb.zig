const std = @import("std");
const microzig = @import("microzig");
const rp2xxx = microzig.hal;
const gpio = rp2xxx.gpio;
const time = rp2xxx.time;

const GPIO_Device = rp2xxx.drivers.GPIO_Device;
const ULN2003 = microzig.drivers.stepper.ULN2003;

const uart = rp2xxx.uart.instance.num(0);
const uart_tx_pin = gpio.num(0);

pub const std_options = microzig.std_options(.{
    .logFn = rp2xxx.uart.log,
});

comptime {
    _ = microzig.export_startup();
}

pub fn panic(message: []const u8, _: ?*std.builtin.StackTrace, _: ?usize) noreturn {
    std.log.err("panic: {s}", .{message});
    @breakpoint();
    while (true) {}
}

pub fn main() !void {
    // init uart logging
    uart_tx_pin.set_function(.uart);
    uart.apply(.{
        .clock_config = rp2xxx.clock_config,
    });
    rp2xxx.uart.init_logger(uart);

    // Setup all pins for the stepper driver
    var pins: struct {
        in1: GPIO_Device,
        in2: GPIO_Device,
        in3: GPIO_Device,
        in4: GPIO_Device,
    } = undefined;
    inline for (@typeInfo(@TypeOf(pins)).@"struct".field_names, .{ 17, 16, 14, 15 }) |field_name, num| {
        const pin = gpio.num(num);
        pin.set_function(.sio);
        @field(pins, field_name) = GPIO_Device.init(pin);
    }

    var stepper = ULN2003.init(.{
        .in1_pin = pins.in1.digital_io(),
        .in2_pin = pins.in2.digital_io(),
        .in3_pin = pins.in3.digital_io(),
        .in4_pin = pins.in4.digital_io(),
        .clock_device = rp2xxx.drivers.clock_device(),
        .max_rpm = 30,
    });

    try stepper.begin(20, 1);

    while (true) {
        // Try different microsteps
        inline for (.{ 1, 2 }) |ms| {
            _ = try stepper.set_microstep(ms);
            std.log.info("microsteps: {}", .{ms});
            try stepper.rotate(360);
            time.sleep_ms(250);
            try stepper.rotate(-360);
            time.sleep_ms(250);
        }
        time.sleep_ms(1000);
    }
}
