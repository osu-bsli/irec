const std = @import("std");
const mdf = @import("../root.zig");

// inspired by https://github.com/smart-leds-rs/ws2812-spi-rs/blob/68d98bf9c7f10bc852bace0f3fd5af2a1cef51a7/src/lib.rs

/// WS2812 leds driver. The device should output at a frequency between 2MHz and 3.8MHz. While no
/// bytes are written the output pin **must** be low.
pub fn WS2812(options: struct {
    max_led_count: usize = 1,
    DatagramDevice: type = mdf.base.DatagramDevice,
    ClockDevice: type = mdf.base.ClockDevice,
}) type {
    return struct {
        const Self = @This();

        // we can fit 2 bits (out of 24 bits per color) into 1 byte
        const buffer_size = options.max_led_count * 24 / 2;

        dev: options.DatagramDevice,
        clock_dev: options.ClockDevice,
        next_write_time: ?mdf.base.ClockDevice.Timeout = null,
        buffer: [buffer_size]u8 = undefined,

        /// Initializes the driver.
        pub fn init(dev: options.DatagramDevice, clock_dev: options.ClockDevice) Self {
            return .{
                .dev = dev,
                .clock_dev = clock_dev,
            };
        }

        /// Writes the given colors in order to the device. The slice len **must** be less than the
        /// maximum led count.
        pub fn write(self: *Self, colors: []const Color) !void {
            std.debug.assert(colors.len <= options.max_led_count);

            // ensures that a reset takes place between writes
            if (self.next_write_time) |next_write_time| {
                if (!next_write_time.is_reached()) {
                    self.clock_dev.sleep_us(next_write_time.diff().to_us());
                }
            }

            const patterns: [4]u8 = .{ 0b1000_1000, 0b1000_1110, 0b1110_1000, 0b1110_1110 };

            var i: usize = 0;
            for (colors) |color| {
                const bytes: [3]u8 = .{ color.g, color.r, color.b };
                for (&bytes) |byte| {
                    var remaining = byte;
                    for (0..4) |_| {
                        const bits: u2 = @intCast((remaining & 0b1100_0000) >> 6);
                        self.buffer[i] = patterns[bits];
                        i += 1;
                        remaining <<= 2;
                    }
                }
            }

            try self.dev.connect();
            defer self.dev.disconnect();

            try self.dev.write(self.buffer[0..i]);

            self.next_write_time = self.clock_dev.make_timeout(.from_us(300));
        }
    };
}

pub const Color = struct {
    r: u8,
    g: u8,
    b: u8,
};
