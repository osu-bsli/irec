const std = @import("std");

pub const BaseError = error{ Unsupported, InvalidSector };
pub const WriteError = BaseError || error{ SectorOverrun, WriteDisabled };
pub const ReadError = BaseError || error{ReadDisabled};

pub const VTable = struct {
    enable_write_fn: ?*const fn (*anyopaque) BaseError!void,
    disable_write_fn: ?*const fn (*anyopaque) BaseError!void,
    erase_fn: ?*const fn (*anyopaque, sector: u32) WriteError!void,
    write_fn: ?*const fn (*anyopaque, sector: u32, data: []u8) WriteError!void,
    read_fn: ?*const fn (*anyopaque, offset: u32, data: []u8) ReadError!usize,
    // find_sector_fn: ?*const fn (*anyopaque, offset: u32) BaseError!u32,
    sector_size_fn: ?*const fn (*anyopaque, sector: u32) BaseError!u32,
};

pub const BlockMemory = @This();
ptr: *anyopaque,
vtable: VTable,

pub fn enable_write(mem: BlockMemory) BaseError!void {
    if (mem.vtable.enable_write_fn) |enable_write_fn| {
        return try enable_write_fn(mem.ptr);
    }
}
pub fn disable_write(mem: BlockMemory) BaseError!void {
    if (mem.vtable.disable_write_fn) |disable_write_fn| {
        return try disable_write_fn(mem.ptr);
    }
}
pub fn erase_sector(mem: BlockMemory, sector: u32) WriteError!void {
    const erase_fn = mem.vtable.erase_fn orelse return error.Unsupported;
    return erase_fn(mem.ptr, sector);
}
pub fn write(mem: BlockMemory, sector: u32, data: []u8) WriteError!void {
    const sector_capacity = try mem.sector_size(sector);
    if (data.len > sector_capacity) return error.SectorOverrun;
    try mem.erase_sector(sector);
    const write_fn = mem.vtable.write_fn orelse return error.Unsupported;
    return write_fn(mem.ptr, sector, data);
}
pub fn read(mem: BlockMemory, offset: u32, data: []u8) ReadError!usize {
    const read_fn = mem.vtable.read_fn orelse return error.Unsupported;
    return read_fn(mem.ptr, offset, data);
}
// pub fn findSector(flash: BlockMemory, offset: u32) BaseError!u8 {

// }
pub fn sector_size(mem: BlockMemory, sector: u32) BaseError!u32 {
    const sector_size_fn = mem.vtable.sector_size_fn orelse return error.Unsupported;
    return sector_size_fn(mem.ptr, sector);
}

pub const TestDevice = struct {
    arena: std.heap.ArenaAllocator,
    write_enabled: bool = false,
    read_enabled: bool = false,
    sector_capacity: u32 = 16384,
    num_sectors: u8 = 4,

    pub fn block_memory(td: *TestDevice) BlockMemory {
        return BlockMemory{ .vtable = vtable, .ptr = td };
    }
    pub fn enable_write(ctx: *anyopaque) BaseError!void {
        const td: *TestDevice = @ptrCast(@alignCast(ctx));
        std.debug.print("Enable flash Write\n", .{});
        td.read_enabled = true;
        td.write_enabled = true;
    }
    pub fn disable_write(ctx: *anyopaque) BaseError!void {
        const td: *TestDevice = @ptrCast(@alignCast(ctx));
        std.debug.print("Disable flash Write\n", .{});
        td.read_enabled = false;
        td.write_enabled = false;
    }
    pub fn erase(ctx: *anyopaque, sector: u32) WriteError!void {
        const td: *TestDevice = @ptrCast(@alignCast(ctx));
        if (td.write_enabled) {
            std.debug.print("Erasing sector: {}\n", .{sector});
        } else {
            return error.WriteDisabled;
        }
    }

    pub fn write(ctx: *anyopaque, sector: u32, data: []u8) WriteError!void {
        const td: *TestDevice = @ptrCast(@alignCast(ctx));
        if (td.write_enabled) {
            std.debug.print("Writing offset: {}, data length: {}\n", .{ sector, data.len });
        } else {
            return error.WriteDisabled;
        }
    }
    pub fn read(ctx: *anyopaque, offset: u32, data: []u8) ReadError!usize {
        const td: *TestDevice = @ptrCast(@alignCast(ctx));
        if (td.write_enabled) {
            std.debug.print("Reading offset: {}\n", .{offset});
            const length = data.len;
            for (0..length) |i| {
                data[i] = @intCast(i % 256);
            }
            return length;
        } else {
            return error.ReadDisabled;
        }
    }
    pub fn sector_size(ctx: *anyopaque, sector: u32) BaseError!u32 {
        const td: *TestDevice = @ptrCast(@alignCast(ctx));
        if (sector < td.num_sectors) {
            return td.sector_capacity;
        } else {
            return error.InvalidSector;
        }
    }
    const vtable = VTable{
        .enable_write_fn = TestDevice.enable_write,
        .disable_write_fn = TestDevice.disable_write,
        .erase_fn = TestDevice.erase,
        .write_fn = TestDevice.write,
        .read_fn = TestDevice.read,
        .sector_size_fn = TestDevice.sector_size,
    };
};

test TestDevice {
    const allocator = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer allocator.deinit();
    var td: TestDevice = .{
        .arena = allocator,
    };

    td.sector_capacity = 10;

    const fd = td.block_memory();
    var buffer: [3]u8 = .{ 42, 43, 44 };
    try std.testing.expectError(error.WriteDisabled, fd.write(0, buffer[0..]));
    try std.testing.expectError(error.ReadDisabled, fd.read(0, buffer[0..]));

    try fd.enable_write();

    try fd.write(0, buffer[0..]);
    try std.testing.expectEqual(buffer.len, fd.read(0x123, buffer[0..]));
    var big_buf: [11]u8 = undefined;
    @memset(big_buf[0..], 123);
    try std.testing.expectError(error.SectorOverrun, fd.write(0, big_buf[0..]));
}
