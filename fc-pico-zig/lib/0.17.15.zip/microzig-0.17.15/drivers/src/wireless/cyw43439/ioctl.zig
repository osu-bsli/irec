//! An IOCTL (Input/Output Control) call is sent by the Pico host CPU (RP2040)
//! to the ARM CPU in the WiFi chip, to read or write configuration data, or send
//! a specific command.
//!
//! An event is an unsolicited block of data sent from the WiFi CPU to the host;
//! it can be a notification that an action is complete, or some data that has
//! arrived over the WiFi network.
//!
//! https://iosoft.blog/2022/12/06/picowi_part3/
//!
//! https://github.com/embassy-rs/embassy/blob/main/cyw43/src/structs.rs
//! https://github.com/jbentham/picowi/blob/main/lib/picowi_ioctl.h
//!
const std = @import("std");
const mem = std.mem;
const assert = std.debug.assert;
const testing = std.testing;

const log = std.log.scoped(.cyw43_ioctl);

// Time to wait for ioctl response (msec)
pub const response_wait = response_poll_interval * 8;
// Polling interval for ioctl responses
pub const response_poll_interval = 10;

// SDPCM (Serial Data Packet Communication Module) header
// SDIO/SPI Bus Layer (SDPCM) header
// ref: https://iosoft.blog/2022/12/06/picowi_part3/
const SDP_Header = extern struct {
    len: u16,
    not_len: u16,
    /// Rx/Tx sequence number
    seq: u8,
    ///  4 MSB Channel, 4 LSB arbitrary flags
    cf: ChanFlags,
    /// Length of next data frame, reserved for Tx
    nextlen: u8 = 0,
    /// Data offset from the start of the packet.
    /// Includes BusHeader length and padding after BusHeader.
    hdrlen: u8,
    /// Flow control bits, reserved for Tx
    flow: u8 = 0,
    /// Maximum Sequence number allowed by firmware for Tx
    credit: u8 = 0,
    _reserved: u16 = 0,

    const Chan = enum(u4) {
        control = 0,
        event = 1,
        data = 2,
    };

    const ChanFlags = packed struct(u8) {
        chan: Chan,
        flags: u4 = 0,
    };

    pub fn channel(sdp: SDP_Header) Chan {
        return sdp.cf.chan;
    }

    pub fn validate(sdp: SDP_Header, n: u16) !void {
        if (sdp.len != n) {
            log.err("invalid reponse len actual: {} packet: {}", .{ sdp.len, n });
            return error.Cyw43SdpInvalidBusLen;
        }
        if (sdp.len ^ sdp.not_len != 0xffff) {
            log.err("invalid reponse not len len: {x} notlen: {x}", .{ sdp.len, sdp.not_len });
            return error.Cyw43SdpInvalidNotBusLen;
        }
    }
};

const CDC_Header = extern struct {
    cmd: Cmd,
    outlen: u16,
    inlen: u16 = 0,
    flags: u16 = 0,
    id: u16,
    status: u32 = 0,

    pub fn status_ok(self: CDC_Header) bool {
        //dev/ apsta, ampdu_rx_factor commands are returing status 0xFFFFFFFB
        return self.status == 0 or self.status == 0xFFFFFFFB;
    }
};

pub const Cmd = enum(u32) {
    up = 2,
    down = 3,
    set_infra = 20,
    set_auth = 22,
    set_ssid = 26,
    set_antdiv = 64,
    set_pm = 86,
    set_gmode = 110,
    set_wsec = 134,
    set_band = 142,
    set_wpa_auth = 165,
    set_scan_channel_time = 185,
    get_var = 262,
    set_var = 263,
    set_wsec_pmk = 268,
    _,
};

const BDC_Header = extern struct {
    flags: u8,
    priority: u8,
    flags2: u8,
    offset: u8,

    // Padding after bdc header where data or event bytes starts
    fn padding(self: BDC_Header) usize {
        return @as(usize, self.offset) * 4;
    }
};

// Structure:
//  - 12 bytes sdp header
//  - xx padding bytes (defined by BusHeader.hdrlen)
// than if chan == .control
//  - 16 bytes of cdc header
//  - xx result data in the case of get_var control command
// if chan == .event
//  - 4 bytes bdc header
//  - xx bdc padding bytes (defined in BDC_Header.offset)
//  - 73 bytes of EventPacket
//  - other event bytes
// if chan == .data
//  - 4 bytes bdc header
//  - bdc padding = bdc.offset * 4
//  - data, from this position to the end of the packet
//
// For data packet response, sdp padding is 2 bytes, ad bdc padding 4 bytes,
// that gives 12 + 2 + 4 + 4 = 22 bytes of bus header, before data.
//
// TODO: this needs a complete rework. The serialization logic is fragile and
// likely unsound in places.
pub const Response = struct {
    const Self = @This();

    reader: std.Io.Reader,

    sdp: SDP_Header,
    cdc_hdr: ?CDC_Header = null,
    bdc_hdr: ?BDC_Header = null,

    pub fn init(payload: []const u8) !Self {
        if (payload.len > std.math.maxInt(u16)) {
            return error.TooBig;
        }

        var reader: std.Io.Reader = .fixed(payload);
        const sdp = try reader.takeStruct(SDP_Header, .little);
        try sdp.validate(@intCast(payload.len));
        return .{
            .reader = reader,
            .sdp = sdp,
        };
    }

    // Number of padding bytes after bus header before cdc/bdc header
    fn padding(self: Self) usize {
        return self.sdp.hdrlen - @sizeOf(SDP_Header);
    }

    pub fn cdc(self: *Self) CDC_Header {
        assert(self.sdp.channel() == .control);
        return if (self.cdc_hdr) |cdc_hdr|
            cdc_hdr
        else blk: {
            _ = self.reader.discard(@fromBackingInt(self.padding())) catch unreachable;
            self.cdc_hdr = self.reader.takeStruct(CDC_Header, .little) catch unreachable;
            break :blk self.cdc_hdr.?;
        };
    }

    pub fn bdc(self: *Self) BDC_Header {
        assert(self.sdp.channel() != .control);
        return if (self.bdc_hdr) |bdc_hdr|
            bdc_hdr
        else blk: {
            _ = self.reader.discard(@fromBackingInt(self.padding())) catch unreachable;
            self.bdc_hdr = self.reader.takeStruct(BDC_Header, .little) catch unreachable;
            break :blk self.bdc_hdr.?;
        };
    }

    pub fn data(self: *Self) []const u8 {
        const head: usize = self.padding() + switch (self.sdp.channel()) {
            .control => @sizeOf(CDC_Header),
            .event, .data => @sizeOf(BDC_Header) + self.bdc().padding(),
        };
        const tail = self.sdp.len - @sizeOf(SDP_Header);
        if (head > tail) {
            return &.{};
        }

        return self.reader.buffer[self.reader.seek..self.reader.end];
    }

    // head position and length of the data in the buffer sent to init
    pub fn data_pos(self: *Self) struct { usize, usize } {
        const head: usize = self.sdp.hdrlen + switch (self.sdp.channel()) {
            .control => @sizeOf(CDC_Header),
            .event, .data => @sizeOf(BDC_Header) + self.bdc().padding(),
        };
        return .{ head, self.sdp.len - head };
    }

    pub fn event(self: *Self) ?EventPacket {
        assert(self.sdp.channel() == .event);
        const buf = self.data();
        if (buf.len < @sizeOf(EventPacket)) {
            var zero = mem.zeroes(EventPacket);
            zero.msg.event_type = .none;
            return zero;
        }
        var evt: EventPacket = undefined;
        @memcpy(std.mem.asBytes(&evt), buf[0..@sizeOf(EventPacket)]);
        std.mem.byteSwapAllFields(EventPacket, &evt);

        if (evt.eth.ether_type != 0x886c) return null;
        if (!mem.eql(u8, &evt.hdr.oui, &.{ 0x00, 0x10, 0x18 })) return null;

        return evt;
    }

    pub fn event_scan_result(self: *Self) !struct { EventScanResult, Security } {
        var res: EventScanResult = undefined;
        var sec: Security = .{};

        assert(self.sdp.channel() == .event);
        const buf = self.data();
        if (buf.len < @sizeOf(EventPacket) + @sizeOf(EventScanResult)) {
            return error.Cyw43InsufficientData;
        }
        const res_buf = buf[@sizeOf(EventPacket)..];
        @memcpy(std.mem.asBytes(&res), res_buf[0..@sizeOf(EventScanResult)]);
        res.channel &= 0xff;
        if (res_buf.len < res.ie_offset + res.ie_length) {
            return error.Cyw43InsufficientData;
        }

        // ref: https://github.com/georgerobotics/cyw43-driver/blob/13004039ffe127519f33824bf7d240e1f23fbdcd/src/cyw43_ll.c#L538
        const is_open = res.capability & 0x0010 == 0;
        if (!is_open) sec.wep_psk = true;

        var ie_buf = res_buf[res.ie_offset..][0..res.ie_length];
        while (ie_buf.len >= 2) {
            const typ = ie_buf[0];
            const len = ie_buf[1];
            ie_buf = ie_buf[2..];
            if (typ == 48) {
                sec.wpa2 = true;
            } else {
                const wpa_oui_type1 = "\x00\x50\xF2\x01";
                if (typ == 221 and ie_buf.len >= wpa_oui_type1.len) {
                    if (mem.eql(u8, ie_buf[0..wpa_oui_type1.len], wpa_oui_type1)) {
                        sec.wpa = true;
                    }
                }
            }
            if (ie_buf.len <= len) break;
            ie_buf = ie_buf[len..];
        }

        return .{ res, sec };
    }
};

pub const Security = packed struct {
    wep_psk: bool = false,
    wpa: bool = false,
    wpa2: bool = false,

    pub fn open(s: Security) bool {
        return @as(u3, @bitCast(s)) == 0;
    }
};

pub fn response(buf: []const u8) !Response {
    return Response.init(buf);
}

/// Format command request
pub fn request(
    writer: *std.Io.Writer,
    cmd: Cmd,
    name: []const u8,
    data: []const u8,
    request_id: u16,
    tx_sequence: u8,
) !void {
    // name length with sentinel
    const name_len: usize = name.len + if (name.len > 0) @as(usize, 1) else @as(usize, 0);
    // length of name and data rounded to 4 bytes
    const payload_len: u16 = @intCast(((name_len + (if (data.len > 0 and data.len < 4) 4 else data.len) + 3) >> 2) * 4);
    const header_len: u16 = @sizeOf(SDP_Header) + @sizeOf(CDC_Header);
    const txlen: u16 = header_len + payload_len;

    const sdp: SDP_Header = .{
        .len = txlen,
        .not_len = ~txlen,
        .seq = tx_sequence,
        .cf = .{
            .chan = .control,
            .flags = 0,
        },
        .hdrlen = @sizeOf(SDP_Header),
    };
    try writer.writeStruct(sdp, .little);
    const cdc: CDC_Header = .{
        .cmd = cmd,
        .outlen = payload_len,
        .id = request_id,
        .flags = if (data.len > 0) 0x02 else 0,
    };
    try writer.writeStruct(cdc, .little);
    if (name_len > 0) {
        try writer.writeAll(name);
        try writer.writeByte(0);
    }
    if (data.len > 0) {
        try writer.writeAll(data);
    }

    // set paddnig bytes to 0
    try writer.splatByteAll(0, txlen - (header_len + name_len + data.len));
}

pub const TxHeader = extern struct {
    const Self = @This();

    sdp: SDP_Header = mem.zeroes(SDP_Header),
    _padding: u16 = 0,
    bdc: BDC_Header = mem.zeroes(BDC_Header),

    pub fn init(data_len: u16, tx_sequence: u8) Self {
        const txlen = @sizeOf(TxHeader) + data_len;
        var self: Self = .{};
        self.sdp = .{
            .len = txlen,
            .not_len = ~txlen,
            .seq = tx_sequence,
            .cf = .{
                .chan = .data,
                .flags = 0,
            },
            .hdrlen = @sizeOf(SDP_Header) + 2,
        };
        self.bdc.flags = 0x20;
        return self;
    }
};

pub const tx_header_len = @sizeOf(TxHeader);

pub fn tx_header(data_len: u16, tx_sequence: u8) [tx_header_len]u8 {
    return @bitCast(TxHeader.init(data_len, tx_sequence));
}

comptime {
    assert(@sizeOf(SDP_Header) == 12);
    assert(@sizeOf(BDC_Header) == 4);
    assert(@sizeOf(CDC_Header) == 16);
    assert(@sizeOf(EventPacket) == 72);
    assert(@sizeOf(TxHeader) == 18);
}

test "request" {
    {
        var buf: [64]u8 = undefined;
        const req = request(&buf, .get_var, "cur_etheraddr", &.{}, 3, 3);

        const expected = &hex_to_bytes("2C00D3FF0300000C00000000060100001000000000000300000000006375725F657468657261646472000000");
        try std.testing.expectEqualSlices(u8, expected, req);
    }
    {
        const expected = &hex_to_bytes("2C00D3FF0700000C00000000070100001000000002000700000000006770696F6F7574000100000001000000");
        var data: [8]u8 = @splat(0);
        data[0] = 1;
        data[4] = 1;
        var buf: [64]u8 = undefined;
        const req = request(&buf, .set_var, "gpioout", &data, 7, 7);
        try std.testing.expectEqualSlices(u8, expected, req);
    }
}

test "parse response" {
    const expected = &hex_to_bytes("2CCF67F3B7EA");
    const rsp_bytes = &hex_to_bytes("0001FFFE040000DC0014000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000060100001400000000000300000000002CCF67F3B7EA6865726164647200000000000000");
    try testing.expectEqual(256, rsp_bytes.len);
    const rsp = try Response.init(rsp_bytes);

    try testing.expectEqual(256, rsp.sdp.len);
    try testing.expectEqual(0xffff, rsp.sdp.len ^ rsp.sdp.not_len);
    try testing.expectEqual(4, rsp.sdp.seq);
    try testing.expectEqual(220, rsp.sdp.hdrlen);
    try testing.expectEqual(20, rsp.sdp.credit);
    try testing.expectEqual(0, rsp.sdp.nextlen);

    const ioctl = rsp.cdc();
    try testing.expectEqual(.get_var, ioctl.cmd);
    try testing.expectEqual(20, ioctl.outlen);
    try testing.expectEqual(0, ioctl.inlen);
    try testing.expectEqual(3, ioctl.id);
    try testing.expectEqual(0, ioctl.flags);
    try testing.expectEqual(0, ioctl.status);

    try testing.expectEqualSlices(u8, expected, rsp.data()[0..expected.len]);
    const head, const len = rsp.data_pos();
    try testing.expectEqual(236, head);
    try testing.expectEqual(20, len);
    try testing.expectEqualSlices(u8, expected, rsp_bytes[head..][0..len][0..expected.len]);
}

pub fn hex_to_bytes(comptime hex: []const u8) [hex.len / 2]u8 {
    var res: [hex.len / 2]u8 = undefined;
    _ = std.fmt.hexToBytes(&res, hex) catch unreachable;
    return res;
}

const EventPacket = extern struct {
    eth: EthernetHeader,
    hdr: EventHeader,
    msg: EventMessage,
};

// Escan result event (excluding 12-byte IOCTL header and BDC header)
pub const EventScanResult = extern struct {
    // Scan result header
    const Header = extern struct {
        buflen: u32,
        version: u32,
        sync_id: u16,
        bss_count: u16,
    };

    hdr: Header,

    version: u32, // version field
    length: u32, // byte length of data in this record, starting at version and including IEs
    bssid: [6]u8, // The MAC address of the Access Point (AP)
    beacon_period: u16, // Interval between two consecutive beacon frames. Units are Kusec
    capability: u16, // Capability information
    ssid_len: u8, // SSID length
    ssid: [32]u8, // Array to store SSID
    nrates: u32, // Count of rates in this set
    rates: [16]u8, // rates in 500kbps units, higher bit set if basic
    channel: u16, // Channel specification for basic service set
    atim_window: u16, // Announcement traffic indication message window size. Units are Kusec
    dtim_period: u8, // Delivery traffic indication message period
    rssi: u16, // receive signal strength (in dBm)
    phy_noise: u8, // noise (in dBm)
    // The following fields assume the 'version' field is 109 (0x6D)
    n_cap: u8, // BSS is 802.11N Capable
    nbss_cap: u32, // 802.11N BSS Capabilities (based on HT_CAP_*)
    ctl_ch: u8, // 802.11N BSS control channel number
    reserved1: u32, // Reserved for expansion of BSS properties
    flags: u8, // flags
    reserved2: [3]u8, // Reserved for expansion of BSS properties
    basic_mcs: [16]u8, // 802.11N BSS required MCS set
    ie_offset: u16, // offset at which IEs start, from beginning
    ie_length: u32, // byte length of Information Elements
    snr: u16, // Average SNR(signal to noise ratio) during frame reception
    // Variable-length Information Elements follow, see cyw43_ll_wifi_parse_scan_result
};

// Ethernet header (sdpcm_ethernet_header_t)
const EthernetHeader = extern struct {
    dest_mac: [6]u8,
    source_mac: [6]u8,
    ether_type: u16,
};

// Vendor-specific (Broadcom) Ethernet header (sdpcm_bcmeth_header_t)
const EventHeader = extern struct {
    subtype: u16,
    len: u16,
    ver: u8,
    oui: [3]u8,
    usr_subtype: u16,
};

// Raw event header (sdpcm_raw_event_header_t)
pub const EventMessage = extern struct {
    version: u16,
    flags: u16,
    event_type: EventType,
    status: EventStatus,
    reason: u32,
    auth_type: u32,
    datalen: u32,
    addr: [6]u8,
    ifname: [16]u8,
    ifidx: u8,
    bsscfgidx: u8,
};

// Async events
pub const EventType = enum(u32) {
    // zig fmt: off
    none                           =   0xffffffff,
    set_ssid                       =   0, // indicates status of set ssid ,
    join                           =   1, // differentiates join ibss from found (wlc_e_start) ibss
    start                          =   2, // sta founded an ibss or ap started a bss
    auth                           =   3, // 802.11 auth request
    auth_ind                       =   4, // 802.11 auth indication
    deauth                         =   5, // 802.11 deauth request
    deauth_ind                     =   6, // 802.11 deauth indication
    assoc                          =   7, // 802.11 assoc request
    assoc_ind                      =   8, // 802.11 assoc indication
    reassoc                        =   9, // 802.11 reassoc request
    reassoc_ind                    =  10, // 802.11 reassoc indication
    disassoc                       =  11, // 802.11 disassoc request
    disassoc_ind                   =  12, // 802.11 disassoc indication
    quiet_start                    =  13, // 802.11h quiet period started
    quiet_end                      =  14, // 802.11h quiet period ended
    beacon_rx                      =  15, // beacons received/lost indication
    link                           =  16, // generic link indication
    mic_error                      =  17, // tkip mic error occurred
    ndis_link                      =  18, // ndis style link indication
    roam                           =  19, // roam attempt occurred: indicate status & reason
    txfail                         =  20, // change in dot11failedcount (txfail)
    pmkid_cache                    =  21, // wpa2 pmkid cache indication
    retrograde_tsf                 =  22, // current ap's tsf value went backward
    prune                          =  23, // ap was pruned from join list for reason
    autoauth                       =  24, // report autoauth table entry match for join attempt
    eapol_msg                      =  25, // event encapsulating an eapol message
    scan_complete                  =  26, // scan results are ready or scan was aborted
    addts_ind                      =  27, // indicate to host addts fail/success
    delts_ind                      =  28, // indicate to host delts fail/success
    bcnsent_ind                    =  29, // indicate to host of beacon transmit
    bcnrx_msg                      =  30, // send the received beacon up to the host
    bcnlost_msg                    =  31, // indicate to host loss of beacon
    roam_prep                      =  32, // before attempting to roam
    pfn_net_found                  =  33, // pfn network found event
    pfn_net_lost                   =  34, // pfn network lost event
    reset_complete                 =  35,
    join_start                     =  36,
    roam_start                     =  37,
    assoc_start                    =  38,
    ibss_assoc                     =  39,
    radio                          =  40,
    psm_watchdog                   =  41, // psm microcode watchdog fired
    ccx_assoc_start                =  42, // ccx association start
    ccx_assoc_abort                =  43, // ccx association abort
    probreq_msg                    =  44, // probe request received
    scan_confirm_ind               =  45,
    psk_sup                        =  46, // wpa handshake
    country_code_changed           =  47,
    exceeded_medium_time           =  48, // wmmac excedded medium time
    icv_error                      =  49, // wep icv error occurred
    unicast_decode_error           =  50, // unsupported unicast encrypted frame
    multicast_decode_error         =  51, // unsupported multicast encrypted frame
    trace                          =  52,
    bta_hci_event                  =  53, // bt-amp hci event
    i_f                            =  54, // i/f change (for wlan host notification)
    p2p_disc_listen_complete       =  55, // p2p discovery listen state expires
    rssi                           =  56, // indicate rssi change based on configured levels
    pfn_best_batching              =  57, // pfn best network batching event
    extlog_msg                     =  58,
    action_frame                   =  59, // action frame reception
    action_frame_complete          =  60, // action frame tx complete
    pre_assoc_ind                  =  61, // assoc request received
    pre_reassoc_ind                =  62, // re-assoc request received
    channel_adopted                =  63, // channel adopted (xxx: obsoleted)
    ap_started                     =  64, // ap started
    dfs_ap_stop                    =  65, // ap stopped due to dfs
    dfs_ap_resume                  =  66, // ap resumed due to dfs
    wai_sta_event                  =  67, // wai stations event
    wai_msg                        =  68, // event encapsulating an wai message
    escan_result                   =  69, // escan result event
    action_frame_off_chan_complete =  70, // action frame off channel complete   /* note - this used to be wlc_e_wake_event
    probresp_msg                   =  71, // probe response received
    p2p_probreq_msg                =  72, // p2p probe request received
    dcs_request                    =  73,
    fifo_credit_map                =  74, // credits for d11 fifos. [ac0,ac1,ac2,ac3,bc_mc,atim]
    action_frame_rx                =  75, // received action frame event with wl_event_rx_frame_data_t header
    wake_event                     =  76, // wake event timer fired, used for wake wlan test mode
    rm_complete                    =  77, // radio measurement complete
    htsfsync                       =  78, // synchronize tsf with the host
    overlay_req                    =  79, // request an overlay ioctl/iovar from the host
    csa_complete_ind               =  80,
    excess_pm_wake_event           =  81, // excess pm wake event to inform host
    pfn_scan_none                  =  82, // no pfn networks around
    pfn_scan_allgone               =  83, // last found pfn network gets lost
    gtk_plumbed                    =  84,
    assoc_ind_ndis                 =  85, // 802.11 assoc indication for ndis only
    reassoc_ind_ndis               =  86, // 802.11 reassoc indication for ndis only
    assoc_req_ie                   =  87,
    assoc_resp_ie                  =  88,
    assoc_recreated                =  89, // association recreated on resume
    action_frame_rx_ndis           =  90, // rx action frame event for ndis only
    auth_req                       =  91, // authentication request received
    tdls_peer_event                =  92, // discovered peer, connected/disconnected peer
    //mesh_dhcp_success              =  92, // dhcp handshake successful for a mesh interface
    speedy_recreate_fail           =  93, // fast assoc recreation failed
    native                         =  94, // port-specific event and payload (e.g. ndis)
    pktdelay_ind                   =  95, // event for tx pkt delay suddently jump
    awdl_aw                        =  96, // awdl aw period starts
    awdl_role                      =  97, // awdl master/slave/ne master role event
    awdl_event                     =  98, // generic awdl event
    nic_af_txs                     =  99, // nic af txstatus
    nan                            = 100, // nan event
    beacon_frame_rx                = 101,
    service_found                  = 102, // desired service found
    gas_fragment_rx                = 103, // gas fragment received
    gas_complete                   = 104, // gas sessions all complete
    p2po_add_device                = 105, // new device found by p2p offload
    p2po_del_device                = 106, // device has been removed by p2p offload
    wnm_sta_sleep                  = 107, // wnm event to notify sta enter sleep mode
    txfail_thresh                  = 108, // indication of mac tx failures (exhaustion of 802.11 retries) exceeding threshold(s)
    proxd                          = 109, // proximity detection event
    ibss_coalesce                  = 110, // ibss coalescing
    //mesh_paired                    = 110, // mesh peer found and paired
    awdl_rx_prb_resp               = 111, // awdl rx probe response
    awdl_rx_act_frame              = 112, // awdl rx action frames
    awdl_wowl_nullpkt              = 113, // awdl wowl nulls
    awdl_phycal_status             = 114, // awdl phycal status
    awdl_oob_af_status             = 115, // awdl oob af status
    awdl_scan_status               = 116, // interleaved scan status
    awdl_aw_start                  = 117, // awdl aw start
    awdl_aw_end                    = 118, // awdl aw end
    awdl_aw_ext                    = 119, // awdl aw extensions
    awdl_peer_cache_control        = 120,
    csa_start_ind                  = 121,
    csa_done_ind                   = 122,
    csa_failure_ind                = 123,
    cca_chan_qual                  = 124, // cca based channel quality report
    bssid                          = 125, // to report change in bssid while roaming
    tx_stat_error                  = 126, // tx error indication
    bcmc_credit_support            = 127, // credit check for bcmc supported
    psta_primary_intf_ind          = 128, // psta primary interface indication
    bt_wifi_handover_req           = 130, // handover request initiated
    spw_txinhibit                  = 131, // southpaw txinhibit notification
    fbt_auth_req_ind               = 132, // fbt authentication request indication
    rssi_lqm                       = 133, // enhancement addition for wlc_e_rssi
    pfn_gscan_full_result          = 134, // full probe/beacon (ies etc) results
    pfn_swc                        = 135, // significant change in rssi of bssids being tracked
    authorized                     = 136, // a sta been authroized for traffic
    probreq_msg_rx                 = 137, // probe req with wl_event_rx_frame_data_t header
    pfn_scan_complete              = 138, // pfn completed scan of network list
    rmc_event                      = 139, // rmc event
    dpsta_intf_ind                 = 140, // dpsta interface indication
    rrm                            = 141, // rrm event
    ulp                            = 146, // ulp entry event

    tko                            = 151, // TCP Keep Alive Offload Event
    ext_auth_req                   = 187, // authentication request received
    ext_auth_frame_rx              = 188, // authentication request received
    mgmt_frame_txstatus            = 189, // mgmt frame Tx complete
    _,
    // zig fmt: on

    pub fn mask(events: []const EventType) [26]u8 {
        var m: [26]u8 = @splat(0);
        for (events) |event| {
            const e: u32 = @backingInt(event);
            m[4 + e / 8] |= @as(u8, 1) << @as(u3, @truncate(e & 7));
        }
        return m;
    }
};

pub const EventStatus = enum(u32) {
    /// operation was successful
    success = 0,
    /// operation failed
    fail = 1,
    /// operation timed out
    timeout = 2,
    /// failed due to no matching network found
    no_networks = 3,
    /// operation was aborted
    abort = 4,
    /// protocol failure: packet not ack'd
    no_ack = 5,
    /// AUTH or ASSOC packet was unsolicited
    unsolicited = 6,
    /// attempt to assoc to an auto auth configuration
    attempt = 7,
    /// scan results are incomplete
    partial = 8,
    /// scan aborted by another scan
    newscan = 9,
    /// scan aborted due to assoc in progress
    newassoc = 10,
    /// 802.11h quiet period started
    hquiet = 11,
    /// user disabled scanning (WLC_SET_SCANSUPPRESS)
    suppress = 12,
    /// no allowable channels to scan
    nochans = 13,
    /// scan aborted due to CCX fast roam
    ccxfastrm = 14,
    /// abort channel select
    cs_abort = 15,
    _,
};

test "pwd encode" {
    var buf: [36]u8 = @splat(0);

    try testing.expectEqualSlices(
        u8,
        &hex_to_bytes("0A0001005065726F5A6465726F31"),
        encode_pwd(&buf, "PeroZdero1"),
    );

    try testing.expectEqualSlices(
        u8,
        &hex_to_bytes("080000006E696E617A617261"),
        encode_ssid(&buf, "ninazara"),
    );
}

pub fn encode_pwd(buf: []u8, pwd: []const u8) []u8 {
    mem.writeInt(u32, buf[0..4], @intCast(pwd.len | 0x10000), .little);
    @memcpy(buf[4..][0..pwd.len], pwd);
    return buf[0 .. 4 + pwd.len];
}

pub fn encode_sae_pwd(buf: []u8, pwd: []const u8) []u8 {
    mem.writeInt(u16, buf[0..2], @intCast(pwd.len), .little);
    @memcpy(buf[2..][0..pwd.len], pwd);
    return buf[0 .. 2 + pwd.len];
}

pub fn encode_ssid(buf: []u8, ssid: []const u8) []u8 {
    mem.writeInt(u32, buf[0..4], @intCast(ssid.len), .little);
    @memcpy(buf[4..][0..ssid.len], ssid);
    return buf[0 .. 4 + ssid.len];
}

pub fn bytes_to_words(bytes: []const u8) struct { []const u32, ?u32 } {
    const padding_bytes = bytes.len & 0b11;
    const round_len = bytes.len - padding_bytes;
    const words: []const u32 =
        if (round_len > 0)
            @alignCast(mem.bytesAsSlice(u32, @constCast(bytes)[0..round_len]))
        else
            &.{};

    var padding_word: u32 = 0;
    for (0..padding_bytes) |i| {
        const b = bytes[bytes.len - 1 - i];
        padding_word = (padding_word << 8) | b;
    }
    return .{ words, if (padding_bytes == 0) null else padding_word };
}

test bytes_to_words {
    {
        const hex = hex_to_bytes("aabbcc");
        var bytes: [hex.len]u8 align(4) = undefined;
        @memcpy(&bytes, &hex);

        const words, const padding = bytes_to_words(&bytes);
        try testing.expectEqual(0, words.len);
        try testing.expectEqual(0xccbbaa, padding.?);
    }
    {
        const hex = hex_to_bytes("aabbccddeeff1122334455");
        var bytes: [hex.len]u8 align(4) = undefined;
        @memcpy(&bytes, &hex);

        const words, const padding = bytes_to_words(&bytes);
        try testing.expectEqualSlices(u32, &.{ 0xddccbbaa, 0x2211ffee }, words);
        try testing.expectEqual(0x554433, padding.?);
    }
}

test "unaligned" {
    const hex = hex_to_bytes("aabbccddeeff1122334455");
    const bytes = hex[0..5];

    // var bytes2: []u8 = undefined;
    // bytes2.ptr = @constCast(bytes.ptr);
    // bytes2.len = 8;
    // const words: []u32 = @alignCast(mem.bytesAsSlice(u32, @constCast(bytes2)));

    var words: []u32 = undefined;
    words.ptr = @ptrCast(@alignCast(@constCast(bytes.ptr)));
    words.len = 2;

    try testing.expectEqualSlices(u32, &.{ 0xddccbbaa, 0x2211ffee }, words);
}

test "small data is padded in request to 4 bytes" {
    var buf: [1024]u8 = undefined;

    const r1 = request(&buf, .set_var, "ampdu_ba_wsize", &.{ 0x08, 0, 0, 0 }, 1, 2);
    const r2 = request(buf[512..], .set_var, "ampdu_ba_wsize", &.{0x08}, 1, 2);

    try testing.expectEqualSlices(u8, r1, r2);
}

test "events mask" {
    const buf = hex_to_bytes("000000008B120102004000000000800100000000000000000000");
    try testing.expectEqual(26, buf.len);
    const mask = EventType.mask(&.{
        .join,
        .assoc,
        .reassoc,
        .assoc_req_ie,
        .assoc_resp_ie,
        .set_ssid,
        .link,
        .auth,
        .psk_sup,
        .eapol_msg,
        .disassoc_ind,
    });
    try testing.expectEqualSlices(u8, &buf, &mask);
}
