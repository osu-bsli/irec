/// Platform independent network library. Connects lwip with underlying network
/// link interface.
const std = @import("std");
const config = @import("config");
const Link = @import("link");

const assert = std.debug.assert;
fn assert_panic(ok: bool, msg: []const u8) void {
    if (!ok) @panic(msg);
}

pub const lwip = @import("lwip").c;

const log = std.log.scoped(.lwip);

pub const Interface = struct {
    const Self = @This();

    netif: lwip.netif = .{},
    dhcp: lwip.dhcp = .{},
    link: Link,
    status_flags: u16 = 0,

    stat: struct {
        poll_count: usize = 0,
        tick_count: usize = 0,
        recv_packets: usize = 0,
        recv_bytes: usize = 0,
        send_packets: usize = 0,
        send_bytes: usize = 0,
    } = .{},

    pub const Options = struct {
        fixed: ?Fixed = null,

        pub const Fixed = struct {
            ip: lwip.ip4_addr,
            netmask: lwip.ip4_addr,
            gw: lwip.ip4_addr,

            pub fn init(ip: []const u8, netmask: []const u8, gw: []const u8) !Fixed {
                var f: Fixed = undefined;
                if (lwip.ip4addr_aton(ip.ptr, &f.ip) != 1 or
                    lwip.ip4addr_aton(netmask.ptr, &f.netmask) != 1 or
                    lwip.ip4addr_aton(gw.ptr, &f.gw) != 1)
                    return error.IpAddrParse;
                return f;
            }
        };
    };

    pub fn init(self: *Self, mac: [6]u8, opt: Options) !void {
        lwip.lwip_init();
        const netif: *lwip.netif = &self.netif;

        if (opt.fixed) |fixed| {
            _ = lwip.netif_add(
                netif,
                &fixed.ip,
                &fixed.netmask,
                &fixed.gw,
                null,
                c_netif_init,
                lwip.netif_input,
            ) orelse return error.OutOfMemory;
        } else {
            _ = lwip.netif_add_noaddr(
                netif,
                null,
                c_netif_init,
                lwip.netif_input,
            ) orelse return error.OutOfMemory;
        }

        std.mem.copyForwards(u8, &netif.hwaddr, &mac);
        lwip.netif_create_ip6_linklocal_address(netif, 1);
        netif.ip6_autoconfig_enabled = 1;
        lwip.netif_set_default(netif);
        lwip.netif_set_up(netif);
        lwip.netif_set_status_callback(netif, c_on_netif_status);
        lwip.netif_set_link_callback(netif, c_on_netif_status);
        if (opt.fixed == null) {
            lwip.dhcp_set_struct(netif, &self.dhcp);
            try c_err(lwip.dhcp_start(netif));
        }
    }

    // synchronously called from init (during netif_add)
    fn c_netif_init(netif_c: [*c]lwip.netif) callconv(.c) lwip.err_t {
        const netif: *lwip.netif = netif_c;
        netif.linkoutput = c_netif_linkoutput;
        netif.output = lwip.etharp_output;
        netif.output_ip6 = lwip.ethip6_output;
        netif.mtu = config.mtu;
        netif.flags = lwip.NETIF_FLAG_BROADCAST | lwip.NETIF_FLAG_ETHARP |
            lwip.NETIF_FLAG_ETHERNET | lwip.NETIF_FLAG_IGMP | lwip.NETIF_FLAG_MLD6;
        netif.hwaddr_len = lwip.ETH_HWADDR_LEN;
        return lwip.ERR_OK;
    }

    fn c_on_netif_status(netif_c: [*c]lwip.netif) callconv(.c) void {
        const netif: *lwip.netif = netif_c;
        const self: *Self = @fieldParentPtr("netif", netif);

        const new_flags: u16 = (if (self.ready()) @as(u16, 1) else 0) << 8 | netif.flags;
        if (self.status_flags == new_flags) return;
        self.status_flags = new_flags;
        log.debug("netif status callback is_link_up: {:<5} is_up: {:<5} ready: {:<5} ip: {s}", .{
            netif.flags & lwip.NETIF_FLAG_LINK_UP > 0,
            netif.flags & lwip.NETIF_FLAG_UP > 0,
            self.ready(),
            lwip.ipaddr_ntoa(&netif.ip_addr),
        });
    }

    /// Called by lwip when there is a packet to send.
    /// pbuf chain total_len is <= netif.mtu + ethernet header
    fn c_netif_linkoutput(netif_c: [*c]lwip.netif, pbuf_c: [*c]lwip.pbuf) callconv(.c) lwip.err_t {
        const netif: *lwip.netif = netif_c;
        var pbuf: *lwip.pbuf = pbuf_c;
        const self: *Self = @fieldParentPtr("netif", netif);

        if (config.pbuf_header_length > 0 and lwip.pbuf_header(pbuf, config.pbuf_header_length) != 0) {
            log.err("can't get pbuf headroom len: {}, tot_len: {} ", .{ pbuf.len, pbuf.tot_len });
            return lwip.ERR_ARG;
        }

        if (pbuf.next != null) {
            // clone chain into single packet buffer
            pbuf = lwip.pbuf_clone(lwip.PBUF_RAW, lwip.PBUF_POOL, pbuf) orelse return lwip.ERR_MEM;
        }
        defer {
            // free local pbuf clone (if clone was made)
            if (pbuf_c.*.next != null) _ = lwip.pbuf_free(pbuf);
        }

        self.link.vtable.send(self.link.ptr, payload_bytes(pbuf)) catch |err| {
            return switch (err) {
                error.OutOfMemory => lwip.ERR_MEM,
                error.LinkDown => lwip.ERR_IF,
                else => lwip.ERR_ARG,
            };
        };
        self.stat.send_packets +%= 1;
        self.stat.send_bytes +%= pbuf.len;
        return lwip.ERR_OK;
    }

    pub fn ready(self: *Self) bool {
        const netif = &self.netif;
        return (netif.flags & lwip.NETIF_FLAG_UP > 0) and
            (netif.flags & lwip.NETIF_FLAG_LINK_UP > 0) and
            (netif.ip_addr.u_addr.ip4.addr != 0 or netif.ip_addr.u_addr.ip6.addr[0] != 0);
    }

    /// Must be called periodically if poll is not called (e.g when using rx
    /// interrupt). Good rule of thumb seems to be every 10-50 ms.
    pub fn tick(self: *Self) void {
        self.stat.tick_count +%= 1;
        lwip.sys_check_timeouts();
    }

    /// Poll underlying link layer for data packet.
    pub fn poll(self: *Self) !void {
        self.stat.poll_count +%= 1;
        lwip.sys_check_timeouts();
        const netif = &self.netif;
        while (true) {
            // get packet buffer of the max size
            const pbuf: *lwip.pbuf = lwip.pbuf_alloc(
                lwip.PBUF_RAW,
                config.pbuf_length,
                lwip.PBUF_POOL,
            ) orelse return error.OutOfMemory;
            assert_panic(
                pbuf.next == null and pbuf.len == pbuf.tot_len and pbuf.len == config.pbuf_length,
                "net.Interface.pool invalid pbuf allocation",
            );
            // receive into that buffer
            const rsp = try self.link.vtable.recv(self.link.ptr, payload_bytes(pbuf));
            // sync link state
            const link_state: Link.RecvResponse.LinkState =
                if (netif.flags & lwip.NETIF_FLAG_LINK_UP > 0) .up else .down;
            if (rsp.link_state != link_state) {
                switch (rsp.link_state) {
                    .up => lwip.netif_set_link_up(netif),
                    .down => lwip.netif_set_link_down(netif),
                }
            }

            if (rsp.len == 0) { // no data release packet buffer and exit loop
                _ = lwip.pbuf_free(pbuf);
                break;
            }

            errdefer _ = lwip.pbuf_free(pbuf); // netif.input: takes ownership of pbuf on success
            // set payload header and len
            if (rsp.head > 0 and lwip.pbuf_header(pbuf, -@as(lwip.s16_t, @intCast(rsp.head))) != 0) {
                return error.InvalidPbufHead;
            }
            pbuf.len = @intCast(rsp.len);
            pbuf.tot_len = @intCast(rsp.len);
            // pass data to the lwip input function
            try c_err(netif.input.?(pbuf, netif));
            self.stat.recv_packets +%= 1;
            self.stat.recv_bytes +%= rsp.len;

            if (rsp.next_packet_available) |next_packet_available| if (!next_packet_available) break;
        }
    }

    pub fn log_mem_stats(self: *Self) void {
        _ = self;
        const stats = lwip.lwip_stats;
        log.debug("stats mem: {}", .{stats.mem});
        log.debug("pbuf pool: {}", .{stats.memp[lwip.MEMP_PBUF_POOL].*});
        log.debug("memp upd pcb:        {}", .{stats.memp[lwip.MEMP_UDP_PCB].*});
        log.debug("memp tcp pcb:        {}", .{stats.memp[lwip.MEMP_TCP_PCB].*});
        log.debug("memp tcp listen pcb: {}", .{stats.memp[lwip.MEMP_TCP_PCB_LISTEN].*});
        log.debug("memp tcp seg:        {}", .{stats.memp[lwip.MEMP_TCP_SEG].*});
        log.debug("memp reassdata:      {}", .{stats.memp[lwip.MEMP_REASSDATA].*});
        log.debug("memp frag buf:       {}", .{stats.memp[lwip.MEMP_FRAG_PBUF].*});
        log.debug("memp igmp group:     {}", .{stats.memp[lwip.MEMP_IGMP_GROUP].*});
        log.debug("memp sys timeout:    {}", .{stats.memp[lwip.MEMP_SYS_TIMEOUT].*});
        log.debug("memp nd6 queue:      {}", .{stats.memp[lwip.MEMP_ND6_QUEUE].*});
        log.debug("memp ip6 reassdata:  {}", .{stats.memp[lwip.MEMP_IP6_REASSDATA].*});
        log.debug("memp mld6 group:     {}", .{stats.memp[lwip.MEMP_MLD6_GROUP].*});
        log.debug("memp pbuf:           {}", .{stats.memp[lwip.MEMP_PBUF].*});
    }
};

fn payload_bytes(pbuf: *lwip.pbuf) []u8 {
    return @as([*]u8, @ptrCast(pbuf.payload.?))[0..pbuf.len];
}

pub const Udp = struct {
    const Self = @This();

    pub const RecvOptions = struct {
        src: Endpoint,
        /// If udp packet is fragmented into multiple lwip packet buffers (pbuf)
        /// this will be false for all except the last fragment.
        last_fragment: bool,
    };
    const OnRecv = *const fn (*Self, []u8, RecvOptions) void;

    pcb: *lwip.udp_pcb,
    on_recv: ?OnRecv = null,

    pub fn init(nic: *Interface) !Self {
        const pcb: *lwip.udp_pcb = lwip.udp_new() orelse return error.OutOfMemory;
        lwip.udp_bind_netif(pcb, &nic.netif);
        pcb.ttl = 64;
        return .{
            .pcb = pcb,
        };
    }

    pub fn send(self: *Self, data: []const u8, target: Endpoint) !void {
        const pbuf: *lwip.pbuf = lwip.pbuf_alloc(
            lwip.PBUF_TRANSPORT,
            @intCast(data.len),
            lwip.PBUF_POOL,
        ) orelse return error.OutOfMemory;
        defer _ = lwip.pbuf_free(pbuf);
        try c_err(lwip.pbuf_take(pbuf, data.ptr, @intCast(data.len)));
        try c_err(lwip.udp_sendto(self.pcb, pbuf, &target.addr, target.port));
    }

    pub fn bind(self: *Self, port: u16, on_recv: OnRecv) !void {
        assert_panic(
            self.on_recv == null,
            "net.Udp.bind already bound",
        );
        self.on_recv = on_recv;
        try c_err(lwip.udp_bind(self.pcb, lwip.IP_ADDR_ANY, port));
        lwip.udp_recv(self.pcb, Self.c_on_recv, self);
    }

    fn c_on_recv(
        ptr: ?*anyopaque,
        _: [*c]lwip.udp_pcb,
        pbuf_c: [*c]lwip.pbuf,
        addr_c: [*c]const lwip.ip_addr,
        port: u16,
    ) callconv(.c) void {
        var pbuf: *lwip.pbuf = pbuf_c;
        const addr: lwip.ip_addr = addr_c[0];
        const self: *Self = @ptrCast(@alignCast(ptr.?));
        defer _ = lwip.pbuf_free(pbuf_c);

        while (true) {
            const last_fragment = pbuf.next == null;
            self.on_recv.?(self, payload_bytes(pbuf), .{
                .last_fragment = last_fragment,
                .src = .{ .addr = addr, .port = port },
            });
            if (last_fragment) break;
            pbuf = pbuf.next;
        }
    }
};

pub const tcp = struct {
    pub fn connect(nic: *Interface, conn: *Connection, target: *Endpoint) !void {
        if (conn.pcb != null or conn.state == .open) return Error.AlreadyConnected;
        if (conn.state != .closed) return Error.AlreadyConnecting;
        conn.nic = nic;

        const pcb: *lwip.tcp_pcb = lwip.tcp_new() orelse return Error.OutOfMemory;
        lwip.tcp_arg(pcb, conn);
        lwip.tcp_err(pcb, Connection.c_on_err);

        errdefer _ = lwip.tcp_close(pcb);
        try c_err(lwip.tcp_connect(pcb, &target.addr, target.port, Connection.c_on_connect));
        conn.state = .connecting;
    }

    pub const Connection = struct {
        const Self = @This();

        const State = enum {
            closed,
            connecting,
            open,
        };

        const OnClose = *const fn (*Self, Error) void;
        const OnRecv = *const fn (*Self, []u8) void;
        const OnSent = *const fn (*Self, u16) void;
        const OnConnect = *const fn (*Self) void;

        nic: ?*Interface = null,
        pcb: ?*lwip.tcp_pcb = null,
        state: State = .closed,
        on_close: ?OnClose = null,
        on_recv: ?OnRecv = null,
        on_sent: ?OnSent = null,
        on_connect: ?OnConnect = null,

        fn open(self: *Self, pcb: *lwip.tcp_pcb) void {
            assert(self.nic != null);
            lwip.tcp_bind_netif(pcb, &self.nic.?.netif);
            lwip.tcp_arg(pcb, self);
            lwip.tcp_recv(pcb, c_on_recv);
            lwip.tcp_sent(pcb, c_on_sent);
            lwip.tcp_err(pcb, c_on_err);
            self.pcb = pcb;
            self.state = .open;
            if (self.on_connect) |cb| cb(self);
        }

        fn c_on_err(ptr: ?*anyopaque, ce: lwip.err_t) callconv(.c) void {
            const self: *Self = @ptrCast(@alignCast(ptr.?));
            // The corresponding pcb is already freed when this callback is called!
            // https://www.nongnu.org/lwip/2_1_x/group__tcp__raw.html#gae1346c4e34d3bc7c01e1b47142ab3121
            self.pcb = null;
            if (self.state != .closed) {
                self.state = .closed;
                if (self.on_close) |cb| cb(self, to_error(ce) orelse return);
            }
        }

        fn c_on_connect(
            ptr: ?*anyopaque,
            c_pcb: [*c]lwip.tcp_pcb,
            ce: lwip.err_t,
        ) callconv(.c) lwip.err_t {
            if (ce != lwip.ERR_OK) return ce; // it is always 0
            const self: *Self = @ptrCast(@alignCast(ptr.?));
            if (self.pcb != null) {
                lwip.tcp_abort(c_pcb);
                return lwip.ERR_ABRT;
            }
            assert_panic(
                self.pcb == null and self.state == .connecting,
                "net.tcp.Connection.c_on_connect invalid state",
            );
            self.open(c_pcb);
            return lwip.ERR_OK;
        }

        fn c_on_recv(
            ptr: ?*anyopaque,
            _: [*c]lwip.tcp_pcb,
            c_pbuf: [*c]lwip.pbuf,
            ce: lwip.err_t,
        ) callconv(.c) lwip.err_t {
            const self: *Self = @ptrCast(@alignCast(ptr.?));
            if (c_pbuf == null) {
                // peer clean close received
                var ret: lwip.err_t = lwip.ERR_OK;
                if (self.pcb != null) {
                    self.close() catch |err| {
                        log.err("c_on_recv close unexpected {}", .{err});
                        ret = lwip.ERR_ABRT;
                    };
                    if (self.on_close) |cb| cb(self, Error.EndOfStream);
                }
                return ret;
            }
            defer _ = lwip.pbuf_free(c_pbuf);

            if (to_error(ce)) |err| {
                if (self.on_close) |cb| cb(self, err);
                return lwip.ERR_OK;
            }

            var pbuf: *lwip.pbuf = c_pbuf;
            while (true) {
                if (self.on_recv) |cb| cb(self, payload_bytes(pbuf));
                if (pbuf.next == null) break;
                pbuf = pbuf.next;
            }
            if (self.pcb) |pcb| {
                lwip.tcp_recved(pcb, c_pbuf.*.tot_len);
            }
            return lwip.ERR_OK;
        }

        fn c_on_sent(ptr: ?*anyopaque, _: [*c]lwip.tcp_pcb, n: u16) callconv(.c) lwip.err_t {
            const self: *Self = @ptrCast(@alignCast(ptr.?));
            if (self.on_sent) |cb| cb(self, n);
            return lwip.ERR_OK;
        }

        pub fn send(self: *Self, bytes: []const u8) !void {
            const pcb = self.pcb orelse return Error.NotConnected;
            try c_err(lwip.tcp_write(pcb, bytes.ptr, @intCast(bytes.len), lwip.TCP_WRITE_FLAG_COPY));
            try c_err(lwip.tcp_output(pcb));
        }

        pub fn close(self: *Self) !void {
            const pcb = self.pcb orelse return Error.NotConnected;
            self.pcb = null;
            self.state = .closed;
            c_err(lwip.tcp_close(pcb)) catch |err| {
                lwip.tcp_abort(pcb);
                return err;
            };
        }

        /// Number of bytes currently available in the TCP send buffer for a
        /// given TCP connection.
        pub fn send_buffer(self: *Self) u16 {
            const pcb = self.pcb orelse return lwip.TCP_SND_BUF;
            return lwip.tcp_sndbuf(pcb);
        }

        pub fn limits(self: *Self) void {
            log.debug(
                "tcp limits current snd_buf: {}, max snd_buf: {}, mss: {}, wnd: {}, snd_queuelen: {}",
                .{
                    self.send_buffer(),
                    lwip.TCP_SND_BUF,
                    lwip.TCP_MSS,
                    lwip.TCP_WND,
                    lwip.TCP_SND_QUEUELEN,
                },
            );
        }
    };

    pub const Server = struct {
        const Self = @This();

        const OnAccept = *const fn () ?*Connection;

        nic: *Interface,
        on_accept: OnAccept,
        pcb: ?*lwip.tcp_pcb = null,

        pub fn bind(self: *Self, port: u16) !void {
            const pcb: *lwip.tcp_pcb = lwip.tcp_new() orelse return Error.OutOfMemory;

            errdefer _ = lwip.tcp_close(pcb);
            try c_err(lwip.tcp_bind(pcb, lwip.IP_ADDR_ANY, port));
            self.pcb = lwip.tcp_listen(pcb);
            lwip.tcp_arg(self.pcb, self);
            lwip.tcp_accept(self.pcb, c_on_accept);
        }

        fn c_on_accept(
            ptr: ?*anyopaque,
            pcb: [*c]lwip.tcp_pcb,
            ce: lwip.err_t,
        ) callconv(.c) lwip.err_t {
            const self: *Self = @ptrCast(@alignCast(ptr.?));
            if (to_error(ce)) |err| {
                log.err("c_on_accept {}", .{err});
                return lwip.ERR_OK;
            }
            var conn = self.on_accept() orelse {
                lwip.tcp_abort(pcb);
                return lwip.ERR_ABRT;
            };
            conn.nic = self.nic;
            conn.open(pcb);
            return lwip.ERR_OK;
        }
    };
};

pub const Endpoint = struct {
    addr: lwip.ip_addr = .{},
    port: u16 = 0,

    pub fn format(self: Endpoint, writer: anytype) !void {
        const ip4_addr: *const lwip.ip4_addr_t = @ptrCast(&self.addr);
        try writer.writeAll(std.mem.sliceTo(lwip.ip4addr_ntoa(ip4_addr), 0));
        var buf: [16]u8 = undefined;
        try writer.writeAll(std.fmt.bufPrint(&buf, ":{}", .{self.port}) catch "");
    }

    pub fn parse(ip: []const u8, port: u16) !Endpoint {
        var target: Endpoint = .{ .port = port };
        if (lwip.ipaddr_aton(ip.ptr, &target.addr) != 1) return error.IpAddrParse;
        return target;
    }
};

pub const Error = error{
    /// Out of memory error.
    OutOfMemory,
    /// Buffer error.
    BufferError,
    /// Timeout.
    Timeout,
    /// Routing problem.
    Routing,
    /// Operation in progress
    InProgress,
    /// Illegal value.
    IllegalValue,
    /// Operation would block.
    WouldBlock,
    /// Address in use.
    AddressInUse,
    /// Already connecting.
    AlreadyConnecting,
    /// Conn already established.
    AlreadyConnected,
    /// Not connected.
    NotConnected,
    /// Low-level netif error
    LowlevelInterfaceError,
    /// Connection aborted.
    ConnectionAborted,
    /// Connection reset.
    ConnectionReset,
    /// Connection closed.
    ConnectionClosed,
    /// Illegal argument.
    IllegalArgument,
    /// All other errors.
    Unknown,
    /// Clean tcp close.
    EndOfStream,
};

fn to_error(e: lwip.err_t) ?Error {
    return switch (e) {
        lwip.ERR_OK => null,
        lwip.ERR_MEM => Error.OutOfMemory,
        lwip.ERR_BUF => Error.BufferError,
        lwip.ERR_TIMEOUT => Error.Timeout,
        lwip.ERR_RTE => Error.Routing,
        lwip.ERR_INPROGRESS => Error.InProgress,
        lwip.ERR_VAL => Error.IllegalValue,
        lwip.ERR_WOULDBLOCK => Error.WouldBlock,
        lwip.ERR_USE => Error.AddressInUse,
        lwip.ERR_ALREADY => Error.AlreadyConnecting,
        lwip.ERR_ISCONN => Error.AlreadyConnected,
        lwip.ERR_CONN => Error.NotConnected,
        lwip.ERR_IF => Error.LowlevelInterfaceError,
        lwip.ERR_ABRT => Error.ConnectionAborted,
        lwip.ERR_RST => Error.ConnectionReset,
        lwip.ERR_CLSD => Error.ConnectionClosed,
        lwip.ERR_ARG => Error.IllegalArgument,
        else => Error.Unknown,
    };
}

fn c_err(res: anytype) Error!void {
    switch (@TypeOf(res)) {
        lwip.err_t => return to_error(res) orelse return,
        lwip.u8_t => if (res != 0) {
            return Error.Unknown;
        },
        else => @compileError("unknown type"),
    }
}

export fn lwip_lock_interrupts(were_enabled: *bool) void {
    _ = were_enabled;
}

export fn lwip_unlock_interrupts(enable: bool) void {
    _ = enable;
}

export fn lwip_assert(msg: [*c]const u8, file: [*c]const u8, line: c_int) void {
    log.err("assert: {s} in file: {s}, line: {}", .{ msg, file, line });
    @panic("lwip assert");
}

export fn lwip_diag(msg: [*c]const u8, file: [*c]const u8, line: c_int) void {
    log.debug("{s} in file: {s}, line: {}", .{ msg, file, line });
}
