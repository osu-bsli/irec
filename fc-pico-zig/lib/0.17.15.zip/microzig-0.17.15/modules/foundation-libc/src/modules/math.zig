//! implementation of `math.h`

