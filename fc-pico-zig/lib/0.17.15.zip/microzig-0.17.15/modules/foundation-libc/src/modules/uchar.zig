//! implementation of `uchar.h`

