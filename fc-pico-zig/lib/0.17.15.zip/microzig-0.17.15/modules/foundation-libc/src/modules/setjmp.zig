//! implementation of `setjmp.h`

